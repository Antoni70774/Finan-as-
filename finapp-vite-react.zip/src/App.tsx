import { Routes, Route, NavLink } from 'react-router-dom'
import Home from './pages/Home'
import Metas from './pages/Metas'
import Perfil from './pages/Perfil'
import { Wallet, Target, User } from 'lucide-react'

export default function App() {
  const linkClass = ({isActive}:{isActive:boolean}) => 
    `px-4 py-2 rounded-xl flex items-center gap-2 ${isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'}`

  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-slate-200">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="font-bold text-lg">FinApp</div>
          <nav className="flex gap-2">
            <NavLink to="/" className={linkClass} end><Wallet className="w-4 h-4"/> Início</NavLink>
            <NavLink to="/metas" className={linkClass}><Target className="w-4 h-4"/> Metas</NavLink>
            <NavLink to="/perfil" className={linkClass}><User className="w-4 h-4"/> Perfil</NavLink>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/metas" element={<Metas/>} />
          <Route path="/perfil" element={<Perfil/>} />
        </Routes>
      </main>
      <footer className="mx-auto max-w-6xl px-4 py-10 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} FinApp — exemplo para GitHub
      </footer>
    </div>
  )
}
