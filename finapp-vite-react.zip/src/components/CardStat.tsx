import { ReactNode } from 'react'

type Props = {
  title: string
  value: string
  sub?: string
  onClick?: () => void
}

export default function CardStat({title, value, sub, onClick}: Props) {
  return (
    <button onClick={onClick} className="card w-full text-left p-4 hover:shadow transition">
      <div className="text-sm text-slate-500">{title}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
      {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
    </button>
  )
}
