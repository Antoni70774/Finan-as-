import { Pie, PieChart, ResponsiveContainer, Tooltip, Cell } from 'recharts'
import type { Lancamento } from '@/lib/types'

type Props = {
  itens: Lancamento[]
}

export default function CategoryChart({itens}: Props) {
  const despesas = itens.filter(i => i.tipo === 'despesa')
  const somaPorCategoria = despesas.reduce<Record<string, number>>((acc, cur) => {
    acc[cur.categoria] = (acc[cur.categoria] ?? 0) + cur.valor
    return acc
  }, {})
  const data = Object.entries(somaPorCategoria).map(([name, value]) => ({name, value}))

  return (
    <div className="card p-4">
      <div className="font-semibold mb-2">Gastos por Categoria</div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" outerRadius="80%">
              {data.map((_, idx) => <Cell key={idx} />)}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
