import type { Lancamento } from '@/lib/types'
import { Utensils, Bus, Home, HeartPulse, Gamepad2, BadgeDollarSign, CircleHelp } from 'lucide-react'

function iconFor(categoria: string) {
  switch (categoria) {
    case 'Alimentação': return Utensils
    case 'Transporte': return Bus
    case 'Moradia': return Home
    case 'Saúde': return HeartPulse
    case 'Lazer': return Gamepad2
    case 'Salário': return BadgeDollarSign
    default: return CircleHelp
  }
}

type Props = { itens: Lancamento[] }

export default function CategorySummary({itens}: Props) {
  const byCat = itens.reduce<Record<string, number>>((acc, cur) => {
    const key = cur.categoria
    acc[key] = (acc[key] ?? 0) + (cur.tipo === 'despesa' ? cur.valor : 0)
    return acc
  }, {})

  const rows = Object.entries(byCat).sort((a,b)=>b[1]-a[1])

  return (
    <div className="card p-4">
      <div className="font-semibold mb-2">Resumo por Categoria</div>
      <div className="grid md:grid-cols-2 gap-3">
        {rows.map(([categoria, total]) => {
          const Icon = iconFor(categoria)
          return (
            <div key={categoria} className="flex items-center gap-3 p-3 border rounded-xl">
              <div className="p-2 rounded-xl border">
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-slate-500">{categoria}</div>
                <div className="font-semibold">R$ {total.toFixed(2)}</div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
