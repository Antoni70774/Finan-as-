import type { Meta } from '@/lib/types'

type Props = {
  meta: Meta
  onUpdate: (meta: Meta) => void
}

export default function GoalCard({meta, onUpdate}: Props) {
  const pct = Math.min(100, Math.round((meta.valorConquistado / meta.valorBem) * 100))
  const restante = Math.max(0, meta.valorBem - meta.valorConquistado)

  function setConquistado(v: number) {
    onUpdate({...meta, valorConquistado: v})
  }

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm text-slate-500">Meta</div>
          <div className="text-xl font-semibold">{meta.titulo}</div>
        </div>
        <div className="tag">Prazo: {new Date(meta.prazoISO).toLocaleDateString('pt-BR')}</div>
      </div>
      <div className="grid md:grid-cols-3 gap-4 mt-4">
        <div className="p-3 border rounded-xl">
          <div className="text-sm text-slate-500">Valor do bem</div>
          <div className="text-lg font-semibold">R$ {meta.valorBem.toFixed(2)}</div>
        </div>
        <div className="p-3 border rounded-xl">
          <div className="text-sm text-slate-500">Conquistado</div>
          <div className="text-lg font-semibold">R$ {meta.valorConquistado.toFixed(2)} ({pct}%)</div>
          <input
            className="mt-2 w-full border rounded-lg px-2 py-1"
            type="number"
            step="0.01"
            value={meta.valorConquistado}
            onChange={e => setConquistado(parseFloat(e.target.value || '0'))}
          />
        </div>
        <div className="p-3 border rounded-xl">
          <div className="text-sm text-slate-500">Previsto a alcançar</div>
          <div className="text-lg font-semibold">{restante <= 0 ? 'Atingido 🎉' : 'R$ ' + restante.toFixed(2)}</div>
          <div className="text-xs text-slate-500 mt-1">Estimativa simples baseada no saldo atual.</div>
        </div>
      </div>
      <div className="mt-4">
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-slate-900" style={{width: `${pct}%`}}/>
        </div>
      </div>
    </div>
  )
}
