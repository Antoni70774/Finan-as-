import { useEffect, useMemo, useState } from 'react'
import type { Lancamento } from '@/lib/types'
import { X } from 'lucide-react'

type Props = {
  open: boolean
  onClose: () => void
  titulo: string
  tipo: 'receita'|'despesa'
  itens: Lancamento[]
  onChange: (itens: Lancamento[]) => void
}

export default function TransactionsModal({open, onClose, titulo, tipo, itens, onChange}: Props) {
  const [local, setLocal] = useState<Lancamento[]>([])

  useEffect(() => {
    setLocal(itens.filter(i => i.tipo === tipo))
  }, [itens, tipo])

  function atualizarItem(id: string, patch: Partial<Lancamento>) {
    const novos = itens.map(i => i.id === id ? {...i, ...patch} : i)
    onChange(novos)
  }

  function excluir(id: string) {
    onChange(itens.filter(i => i.id !== id))
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4">
      <div className="card w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b border-slate-200">
          <h3 className="font-semibold">{titulo}</h3>
          <button className="btn" onClick={onClose}><X className="w-4 h-4"/></button>
        </div>
        <div className="p-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2">Data</th>
                <th>Descrição</th>
                <th>Categoria</th>
                <th className="text-right">Valor (R$)</th>
                <th className="text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {local.length === 0 && (
                <tr><td colSpan={5} className="text-center py-6 text-slate-400">Sem lançamentos</td></tr>
              )}
              {local.map(l => (
                <tr key={l.id} className="border-t">
                  <td className="py-2">
                    <input
                      className="w-36 border rounded-lg px-2 py-1"
                      type="date"
                      value={l.data}
                      onChange={e => atualizarItem(l.id, {data: e.target.value})}
                    />
                  </td>
                  <td>
                    <input
                      className="w-full border rounded-lg px-2 py-1"
                      value={l.descricao}
                      onChange={e => atualizarItem(l.id, {descricao: e.target.value})}
                    />
                  </td>
                  <td>
                    <input
                      className="w-40 border rounded-lg px-2 py-1"
                      value={l.categoria}
                      onChange={e => atualizarItem(l.id, {categoria: e.target.value as any})}
                    />
                  </td>
                  <td className="text-right">
                    <input
                      className="w-28 border rounded-lg px-2 py-1 text-right"
                      type="number"
                      step="0.01"
                      value={l.valor}
                      onChange={e => atualizarItem(l.id, {valor: parseFloat(e.target.value)})}
                    />
                  </td>
                  <td className="text-right">
                    <button className="btn" onClick={() => excluir(l.id)}>Excluir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
