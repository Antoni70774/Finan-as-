import type { Lancamento, Meta } from './types'

export const user = {
  id: 'u1',
  nome: 'Usuário Demo',
  email: 'demo@exemplo.com',
}

export const lancamentosIniciais: Lancamento[] = [
  { id: 'l1', tipo: 'receita', categoria: 'Salário', descricao: 'Salário mensal', valor: 5000, data: '2025-08-01' },
  { id: 'l2', tipo: 'despesa', categoria: 'Moradia', descricao: 'Aluguel', valor: 1800, data: '2025-08-05' },
  { id: 'l3', tipo: 'despesa', categoria: 'Alimentação', descricao: 'Supermercado', valor: 650, data: '2025-08-08' },
  { id: 'l4', tipo: 'despesa', categoria: 'Transporte', descricao: 'Combustível', valor: 320, data: '2025-08-11' },
  { id: 'l5', tipo: 'receita', categoria: 'Outros', descricao: 'Freelancer', valor: 1200, data: '2025-08-12' },
  { id: 'l6', tipo: 'despesa', categoria: 'Lazer', descricao: 'Cinema', valor: 80, data: '2025-08-14' },
  { id: 'l7', tipo: 'despesa', categoria: 'Saúde', descricao: 'Farmácia', valor: 150, data: '2025-08-16' },
]

export const metasIniciais: Meta[] = [
  {
    id: 'm1',
    titulo: 'Comprar notebook',
    valorBem: 6000,
    valorConquistado: 2500,
    prazoISO: '2025-12-31'
  }
]
