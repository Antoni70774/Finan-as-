export type Categoria = 'Alimentação' | 'Transporte' | 'Lazer' | 'Moradia' | 'Saúde' | 'Salário' | 'Outros'

export type Lancamento = {
  id: string
  tipo: 'receita' | 'despesa'
  categoria: Categoria
  descricao: string
  valor: number
  data: string // ISO
}

export type Meta = {
  id: string
  titulo: string
  valorBem: number
  valorConquistado: number
  prazoISO: string
}
