import { useMemo, useState } from 'react'
import CardStat from '@/components/CardStat'
import TransactionsModal from '@/components/TransactionsModal'
import CategoryChart from '@/components/CategoryChart'
import CategorySummary from '@/components/CategorySummary'
import { lancamentosIniciais } from '@/lib/data'
import type { Lancamento } from '@/lib/types'

export default function Home() {
  const [lancamentos, setLancamentos] = useState<Lancamento[]>(lancamentosIniciais)
  const [open, setOpen] = useState<{tipo:'receita'|'despesa'|null}>({tipo:null})

  const { receita, despesa, saldo } = useMemo(() => {
    const receita = lancamentos.filter(l => l.tipo === 'receita').reduce((s,l)=>s+l.valor,0)
    const despesa = lancamentos.filter(l => l.tipo === 'despesa').reduce((s,l)=>s+l.valor,0)
    return { receita, despesa, saldo: receita - despesa }
  }, [lancamentos])

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-3">
        <CardStat title="Receita do mês" value={`R$ ${receita.toFixed(2)}`} onClick={() => setOpen({tipo:'receita'})}/>
        <CardStat title="Despesa do mês" value={`R$ ${despesa.toFixed(2)}`} onClick={() => setOpen({tipo:'despesa'})}/>
        <CardStat title="Balanço do mês" value={`R$ ${saldo.toFixed(2)}`} sub={saldo>=0?'Saldo positivo':'Saldo negativo'}/>
      </div>

      <CategoryChart itens={lancamentos} />

      <CategorySummary itens={lancamentos} />

      <TransactionsModal
        open={open.tipo!==null}
        onClose={() => setOpen({tipo:null})}
        titulo={open.tipo==='receita'?'Receitas':'Despesas'}
        tipo={open.tipo ?? 'despesa'}
        itens={lancamentos}
        onChange={setLancamentos}
      />
    </div>
  )
}
