import { useState } from 'react'
import { metasIniciais } from '@/lib/data'
import GoalCard from '@/components/GoalCard'
import type { Meta } from '@/lib/types'

export default function Metas() {
  const [metas, setMetas] = useState<Meta[]>(metasIniciais)

  function update(meta: Meta) {
    setMetas(metas.map(m => m.id===meta.id ? meta : m))
  }

  return (
    <div className="space-y-6">
      {metas.map(m => <GoalCard key={m.id} meta={m} onUpdate={update}/>)}
      <div className="text-sm text-slate-500">Dica: adicione lógica de previsão com base em depósitos mensais no futuro.</div>
    </div>
  )
}
