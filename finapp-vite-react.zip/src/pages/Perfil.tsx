import { user } from '@/lib/data'

export default function Perfil() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card p-4">
        <div className="font-semibold mb-2">Dados do Usuário</div>
        <div className="space-y-2 text-sm">
          <div><span className="text-slate-500">Nome:</span> {user.nome}</div>
          <div><span className="text-slate-500">E-mail:</span> {user.email}</div>
          <div><span className="text-slate-500">Status:</span> Longado (mock)</div>
        </div>
      </div>

      <div className="card p-4">
        <div className="font-semibold mb-2">Conexões (Open Finance)</div>
        <p className="text-sm text-slate-500 mb-3">Integre com bancos no futuro. Abaixo há switches de demonstração.</p>
        <div className="space-y-3">
          {['Banco A', 'Banco B', 'Banco C'].map(b => (
            <label key={b} className="flex items-center justify-between p-3 border rounded-xl">
              <span>{b}</span>
              <input type="checkbox" className="h-5 w-5"/>
            </label>
          ))}
        </div>
      </div>

      <div className="card p-4 md:col-span-2">
        <div className="font-semibold mb-2">Outras Funções</div>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
          {['Exportar CSV', 'Importar OFX', 'Notificações', 'Segurança', 'Preferências', 'Suporte'].map(f => (
            <button key={f} className="btn">{f}</button>
          ))}
        </div>
      </div>
    </div>
  )
}
